# SA Calculator v77 — QA Report

## Source provenance
- Independent baseline: `SA-Calculator-v76-NEW-LOGO.zip` from the user's Library.
- The v98.27, v98.28, v98.29, v98.30, v98.31, v98.32 and v98.33 ZIPs were not used as the source/UI/system base for this release.
- Existing v76 calculation and provider logic was retained; the UI stylesheet, menu structure, currency picker and keypad routing were rebuilt in this release.

## Automated checks
- `npm test`: 15 tests passed, 0 failed.
- JavaScript syntax: app.js, premium-ui.js, server.js, service-worker.js and scripts/build.js checked.
- HTML: unique IDs and all 17 tool screens/menu destinations checked.
- PWA manifest/package version parity checked by build script.
- Service-worker precache list includes all runtime assets.
- Build script verifies required assets before producing `dist/`.
- ZIP integrity verified at packaging.

## Not physically verified
- No Android APK/Gradle project exists in the v76 source baseline; the included workflow builds/tests the PWA web release and packages source, not a native APK.
- No real Android handset/WebView screenshot, IME, FPS, memory, battery or network test was run in this environment.
- Live exchange rates still depend on network/provider availability and should be tested on the target device.
