# SA Calculator — v77

An independent premium calculator workspace rebuilt from the clean v76 source baseline with a new UI, menu, currency picker and on-demand tool keyboard.

## v77 independent rebuild changes
- Rebuilt the application stylesheet from a clean slate; no v98.27–v98.33 UI/CSS/JS was used as the base.
- Added categorized searchable navigation, Quick Access favorites and four-tab bottom navigation.
- Added a searchable currency picker with country/region flags and ISO codes.
- Kept a permanent keypad only on Basic Calculator; numeric tool fields open the shared keypad on demand.
- Made Number Base keypad open only after a base row is selected.
- Added neutral empty-result states so green success styling is reserved for populated results.
- Preserved the v76 calculation engines, settings, history, currency provider/cache logic and brand assets.

## v76 brand baseline
- Integrated the approved SA Calculator logo artwork throughout the product identity.
- Added optimized 192px and 512px PWA icons, a 180px Apple touch icon, a 64px favicon, and a 1024px master logo.
- Updated the in-app header brand mark, browser favicon, Apple touch icon, PWA manifest, and offline service-worker precache.
- Corrected stale icon references so every declared icon resolves to a real file.
- Bumped release/cache identity to v76 so installed clients can fetch the new brand assets.
- Preserved the existing calculator features and local-storage compatibility from v75.

## Included tools
Calculator, currencies, units, discount, percent, sales tax, body metrics, date, fuel cost, fuel efficiency, grade average, number base, loan / EMI, savings, tip, unit price and world time.

## Run locally
```sh
npm start
```

## Verify
```sh
npm test
```
