# SA Calculator v77 — Tool and Options Matrix

## Navigation
- Bottom navigation: Calculator, Tools, Favorites, Settings.
- Hamburger menu: Quick Access, searchable All Tools, Help.
- Categories: Calculator & Converters; Shopping & Tax; Finance & Planning; Health & Wellness; Date, Time & Travel; Study & Number Systems.
- Favorites are managed in Settings and rendered separately as Quick Access shortcuts.

## Calculator
- Permanent keypad: 0–9, 00, decimal, clear, parentheses, percent, divide, multiply, subtract, add, equals.
- Edit controls: DEG/RAD, power, delete.
- Memory: MC, MR, M+, M−, MS.
- Scientific functions: π, e, log, ln, log₂, square root, cube root, absolute value, power, sin/cos/tan, inverse trig, hyperbolic functions, factorial, reciprocal, percent.
- History: copy, reuse/edit, share, name/rename, protect/unprotect, delete unlocked entries, clear unlocked history.

## Currency Converter
- From currency and To currency selectors.
- Search by country/region, currency name or ISO code.
- Flag, currency name, region and ISO code in picker rows.
- Amount entry, swap, refresh rates, converted amount, rate note and provider/freshness status.
- Numeric keypad appears only when the amount field is tapped; text keyboard is reserved for search.

## Unit Converter
- Categories: Length, Mass/Weight, Area, Volume, Time, Temperature, Energy, Power, Pressure, Speed, Fuel Efficiency, Data Size.
- From unit, To unit, amount, swap and conversion note.
- Numeric keypad appears only on amount-field focus.

## Discount Calculator
- Added tax, original price, discount percentage, amount saved and final price.
- Numeric keypad appears only on field focus.

## Percent Calculator
- Modes: Percent Change (initial/final) and Percent Of (percent/value).
- Result updates from entered values.

## Sales Tax
- Tax rate, calculation mode (Exclusive + Tax / Inclusive − Tax), original price, tax amount and total price.

## Body Metrics
- Height (cm), weight (kg), age and gender (Male/Female).
- BMI, BMR, status and information panel.

## Date Calculator
- Date event name, date, repeat setting, save/cancel, event list and empty state.

## Fuel Cost
- Distance, fuel efficiency and fuel price; calculated fuel required and total cost.

## Fuel Efficiency
- Fuel before, fuel after, refuelled amount and distance; consumed fuel, km/L, L/100 km and MPG.

## Grade Average
- Add/remove course rows, course name, credits and grade; GPA and total credits.

## Number Base
- HEX (16), DEC (10), OCT (8), BIN (2); edit a selected row, synchronized conversions, clear, cursor movement, delete and Done.
- The hexadecimal keypad is hidden until a base row is selected.

## Loan / EMI
- Repayment methods: Equal total payment and Equal principal.
- Principal, annual interest rate, loan period (months), interest-only period.
- Monthly payment, total interest, total payments and amortization schedule.

## Savings
- Deposit amount, compounding frequency (Simple, Annually, Semi-annually, Quarterly, Monthly), period in years, interest rate and interest-income tax.
- After-tax interest income and savings balance.

## Tip
- Check amount, people count, tip percent, optional tax and tip-before-tax toggle.
- Tip amount, final total and amount per person.

## Unit Price
- Compare products A–D by price and quantity; per-unit values and best-value result.

## World Time
- Kolkata reference time, city/time-zone search, city selection, add city, city clock cards and timezone/DST note.

## Settings
- Display: fullscreen, font size, keep screen awake.
- Theme: Light/Dark/System; accent palette; OLED black.
- Calculator: angle unit, live calculation, implicit multiplication.
- Number format: precision Auto/0/2/4/6, separator comma/space/lakh/none, trailing zeros.
- Language: English, Hindi, Urdu, Spanish, French, German, Arabic, Chinese.
- Startup: Calculator or any supported tool, or resume last screen.
- Restore previous inputs; manage/reset favorites.
- History recording and limit 25/50/100/500.
- Auto-copy, key sound, haptic feedback and vibration strength Light/Medium/Strong.
- Diagnostics is disabled by default; clear local cached data is available as a destructive action with confirmation.

## Keyboard rules
- Basic Calculator alone has a permanent keypad.
- Numeric fields in every other tool open the shared 4×4 custom keypad on tap.
- Shared keypad: 0–9, 00, decimal, delete, next, clear and done.
- Search fields use the text keyboard; date fields use the date picker.
- Read-only result fields do not open a keypad.
