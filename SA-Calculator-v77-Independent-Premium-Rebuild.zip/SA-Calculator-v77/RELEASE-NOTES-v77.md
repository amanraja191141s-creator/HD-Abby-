# SA Calculator v77 — Independent Premium Rebuild

- New dark-navy premium visual system; old v76 stylesheet replaced rather than layered over.
- Categorized drawer with Quick Access, searchable All Tools, Help and four-tab bottom navigation.
- Removed redundant header Settings gear and drawer Settings shortcut; Settings has one bottom-navigation destination.
- Searchable currency picker with country/region flags, name, region and ISO code.
- Only Basic Calculator keeps a permanent keypad; all numeric tool fields use the shared on-demand keypad.
- Number Base keypad is shown only after selecting a base row and closes with Done.
- Read-only result fields cannot summon the numeric keypad.
- Empty result cards use neutral styling; success styling is reserved for populated results.
- Preserved the 17 tool destinations, calculation engines, settings, history, currency cache/provider behavior and brand assets from the independent v76 baseline.
