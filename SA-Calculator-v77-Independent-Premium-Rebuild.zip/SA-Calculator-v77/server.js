// Optional secure Xurrency proxy and static server for SA Calculator.
// Run with: XCURRENCY_API_KEY=your_key node server.js
// The browser app calls /api/xurrency/...; the key stays server-side.
'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = Number(process.env.PORT || 8080);
const KEY = process.env.XCURRENCY_API_KEY || '';
const ROOT = path.resolve(__dirname);
const MAX_PROXY_BYTES = 1024 * 1024;
const proxyRequests = new Map();
const PROXY_WINDOW_MS = 60 * 1000;
const PROXY_MAX_REQUESTS = 20;
const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self' https://cdn.jsdelivr.net https://latest.currency-api.pages.dev https://open.er-api.com https://api.frankfurter.dev; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
};

function send(res, status, body, type = 'application/json') {
  if (res.headersSent) return res.destroy();
  res.writeHead(status, {
    'Content-Type': type,
    ...SECURITY_HEADERS,
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function proxy(req, res, pathname) {
  const ip = String(req.socket.remoteAddress || 'unknown');
  const now = Date.now();
  const bucket = proxyRequests.get(ip);
  if (!bucket || now - bucket.startedAt >= PROXY_WINDOW_MS) proxyRequests.set(ip, { startedAt: now, count: 1 });
  else if (++bucket.count > PROXY_MAX_REQUESTS) return send(res, 429, JSON.stringify({ status: 'fail', message: 'Currency proxy rate limit exceeded' }));
  if (!KEY) {
    return send(res, 503, JSON.stringify({ status: 'fail', message: 'Xurrency API key is not configured' }));
  }
  const suffix = pathname.replace(/^\/api\/xurrency\//, '');
  if (!/^([A-Za-z]{3}\/){1}[A-Za-z]{3}(?:\/[A-Za-z]{3})*\/\d+(?:\.\d+)?$/.test(suffix)) {
    return send(res, 400, JSON.stringify({ status: 'fail', message: 'Invalid currency request' }));
  }

  const target = `https://xurrency.com/api/${suffix}${KEY ? '?key=' + encodeURIComponent(KEY) : ''}`;
  const upstream = https.get(target, {
    headers: { Accept: 'application/json', 'User-Agent': 'SA-Calculator/1.83.0-v77' },
    timeout: 10000
  }, (response) => {
    let body = '';
    let received = 0;
    response.on('data', (chunk) => {
      received += chunk.length;
      if (received > MAX_PROXY_BYTES) {
        response.destroy();
        return send(res, 502, JSON.stringify({ status: 'fail', message: 'Currency response too large' }));
      }
      body += chunk;
    });
    response.on('end', () => {
      if (!res.writableEnded) send(res, response.statusCode || 502, body);
    });
    response.on('error', () => {
      if (!res.writableEnded) send(res, 502, JSON.stringify({ status: 'fail', message: 'Currency provider connection failed' }));
    });
  });

  upstream.on('timeout', () => upstream.destroy(new Error('Upstream timeout')));
  upstream.on('error', () => {
    if (!res.writableEnded) send(res, 502, JSON.stringify({ status: 'fail', message: 'Currency provider unavailable' }));
  });
}

function serve(res, pathname) {
  let decoded;
  try {
    decoded = decodeURIComponent(pathname);
  } catch (_) {
    return send(res, 400, 'Bad request', 'text/plain; charset=utf-8');
  }

  const relative = decoded === '/' ? 'index.html' : decoded.replace(/^\/+/, '');
  const file = path.resolve(ROOT, relative);
  const rel = path.relative(ROOT, file);

  // path.relative prevents sibling-prefix traversal (e.g. /app-evil).
  if (rel === '..' || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel)) {
    return send(res, 403, 'Forbidden', 'text/plain; charset=utf-8');
  }
  // Never expose environment/configuration or hidden files over HTTP.
  if (rel.split(path.sep).some((part) => part.startsWith('.'))) {
    return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
  }

  fs.stat(file, (statError, info) => {
    if (statError || !info.isFile()) {
      return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
    }
    fs.readFile(file, (readError, data) => {
      if (readError) return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
      const ext = path.extname(file).toLowerCase();
      const types = {
        '.html': 'text/html; charset=utf-8',
        '.js': 'text/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.svg': 'image/svg+xml',
        '.webmanifest': 'application/manifest+json; charset=utf-8'
      };
      send(res, 200, data, types[ext] || 'application/octet-stream');
    });
  });
}

http.createServer((req, res) => {
  const pathname = url.parse(req.url).pathname || '/';
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.setHeader('Allow', 'GET, HEAD');
    return send(res, 405, 'Method not allowed', 'text/plain; charset=utf-8');
  }
  if (pathname.startsWith('/api/xurrency/')) {
    if (req.method === 'HEAD') return send(res, 405, 'Method not allowed', 'text/plain; charset=utf-8');
    return proxy(req, res, pathname);
  }
  if (req.method === 'HEAD') {
    // Static HEAD requests share GET routing; discard the body after headers.
    const originalEnd = res.end.bind(res);
    res.end = function () { return originalEnd(); };
  }
  return serve(res, pathname);
}).listen(PORT, () => {
  console.log(`SA Calculator server listening on http://localhost:${PORT}`);
});
